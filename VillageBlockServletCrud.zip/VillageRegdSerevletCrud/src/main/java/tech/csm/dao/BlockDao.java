package tech.csm.dao;

import java.util.List;

import tech.csm.entity.Block;

public interface BlockDao {

	List<Block> getAllBlocks();

}
