package tech.csm.service;

import java.util.List;

import tech.csm.entity.Block;

public interface BlockService {

	List<Block> getAllBlocks();

}
