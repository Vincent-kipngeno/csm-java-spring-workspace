package tech.csm.entity;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Entity @Table(name = "t_emp") @Getter @Setter @ToString(exclude ="projs" )
public class Emp implements Serializable {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "emp_id")
	private Integer empId;
	
	@Column(name = "emp_name")
	private String empName;
	
	private Double salary;
	
//	@ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
//	@JoinColumn(name = "dept_id")
	@Column(name = "dept_id")
	private Integer deptId;
	
	@ManyToMany(cascade = CascadeType.ALL)
	@JoinTable(name="t_emp_proj", joinColumns = @JoinColumn(name = "emp_id"), 
				inverseJoinColumns = @JoinColumn(name="proj_id") )
	private List<Proj> projs;
	
	
}
