package tech.csm.runner;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import tech.csm.entity.Aadhar;
import tech.csm.entity.Dept;
import tech.csm.entity.Emp;
import tech.csm.entity.Person;
import tech.csm.entity.Proj;
import tech.csm.util.DBUtil;

public class MappingRunner {

	public static void main(String[] args) {
		Session ses=DBUtil.getSessionFactory().openSession();
//		List<Proj> projectList=new ArrayList<>();
//		projectList.add(ses.get(Proj.class,1));
//		projectList.add(ses.get(Proj.class,2));
//		Emp e=new Emp();
//		e.setEmpName("Sunil Sahoo");
//		e.setSalary(40000.00);
//		e.setDeptId(1);
//		e.setProjs(projectList);
		

		Proj proj=ses.get(Proj.class, 2);
		System.out.println(proj);
		proj.getEmps().forEach(x->System.out.println(x));
		
		
		Transaction tx=ses.beginTransaction();
//		ses.persist(e);
//		Emp emp=ses.get(Emp.class, 4);
//		System.out.println(emp);
//		emp.getProjs().forEach(x->System.out.println(x));
//		
//		
		tx.commit();
		ses.close();
	}

}
