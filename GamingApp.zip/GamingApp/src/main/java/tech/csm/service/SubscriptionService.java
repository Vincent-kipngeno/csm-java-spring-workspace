package tech.csm.service;

import java.util.List;

import tech.csm.domain.Subscription;

public interface SubscriptionService {

	List<Subscription> getAllSubscriptions();

	Double getPriceBySubId(Integer subId);

}
