package tech.csm.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import tech.csm.dao.SubscriptionDao;
import tech.csm.domain.Subscription;

@Service
public class SubscriptionServiceImpl implements SubscriptionService {

	@Autowired
	private SubscriptionDao subscriptionDao;
	
	
	@Override
	public List<Subscription> getAllSubscriptions() {
		
		return subscriptionDao.getAllSubscriptions();
	}


	@Override
	public Double getPriceBySubId(Integer subId) {
		
		return subscriptionDao.getPriceBySubId(subId);
	}

}
