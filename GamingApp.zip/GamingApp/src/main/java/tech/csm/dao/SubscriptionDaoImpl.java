package tech.csm.dao;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import tech.csm.domain.Subscription;

@Repository
public class SubscriptionDaoImpl implements SubscriptionDao {

	@Autowired
	private DataSource dataSource;
	
	
	@Override
	public List<Subscription> getAllSubscriptions() {
		JdbcTemplate jdbcTemplate=new JdbcTemplate(dataSource);
		
		return jdbcTemplate.query("select sub_id,sub_type,price from t_subscription", new BeanPropertyRowMapper<>(Subscription.class));
		
	}

	@Override
	public Double getPriceBySubId(Integer subId) {
		JdbcTemplate jdbcTemplate=new JdbcTemplate(dataSource);
		return jdbcTemplate.queryForObject("select price from t_subscription where sub_id=?",Double.class,new Object[] {subId});
	}

}
