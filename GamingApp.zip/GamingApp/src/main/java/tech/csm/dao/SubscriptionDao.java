package tech.csm.dao;

import java.util.List;

import tech.csm.domain.Subscription;

public interface SubscriptionDao {

	List<Subscription> getAllSubscriptions();

	Double getPriceBySubId(Integer subId);

}
