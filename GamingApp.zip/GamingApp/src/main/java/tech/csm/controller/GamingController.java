package tech.csm.controller;

import java.io.IOException;
import java.net.http.HttpResponse;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import jakarta.servlet.http.HttpServletResponse;
import tech.csm.domain.Subscription;
import tech.csm.service.SubscriptionService;

@Controller
public class GamingController {


	@Autowired
	private SubscriptionService subscriptionService;
	
	
	@GetMapping("/getform")
	public String getRegdForm(Model model) {
		
		List<Subscription> subscriptionList=subscriptionService.getAllSubscriptions();
		model.addAttribute("subscriptionList", subscriptionList);
		
		return "gameregistration";
	}
	
	@GetMapping("/displaySubscriptionFees")
	public void displaySubscriptionFees(@RequestParam Integer subId, 
			@RequestParam Integer duration, HttpServletResponse resp ) throws IOException {
		Double cost=subscriptionService.getPriceBySubId(subId);
		resp.getWriter().print(duration*cost);
	}
	
}
