package tech.csm.dao;

import java.util.List;

import tech.csm.entity.Departments;

public interface DepartmentDao {

	List<Departments> getAllDepartments();

}
