package tech.csm.service;

import java.util.List;

import tech.csm.model.Branch;

public interface BranchService {

	List<Branch> getAllBranches();

}
