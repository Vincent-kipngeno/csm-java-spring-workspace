package tech.csm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentRegdApp1Application {

	public static void main(String[] args) {
		SpringApplication.run(StudentRegdApp1Application.class, args);
	}

}
